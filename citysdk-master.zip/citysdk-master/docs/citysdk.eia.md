# Global





* * *

### categoryRequest(request, callback) 

Call which returns category listings from the dataset explorerRequest should specify category. If no category specified, will default to the root list of datasets{     category: 05}

**Parameters**

**request**: , Call which returns category listings from the dataset explorerRequest should specify category. If no category specified, will default to the root list of datasets{     category: 05}

**callback**: , Call which returns category listings from the dataset explorerRequest should specify category. If no category specified, will default to the root list of datasets{     category: 05}



### seriesRequest(request, callback) 

Call which returns data from the specified seriesRequest should specify a series, if not, nothing will happen{     series: "ELEC.GEN.ALL-AL-99.A"}

**Parameters**

**request**: , Call which returns data from the specified seriesRequest should specify a series, if not, nothing will happen{     series: "ELEC.GEN.ALL-AL-99.A"}

**callback**: , Call which returns data from the specified seriesRequest should specify a series, if not, nothing will happen{     series: "ELEC.GEN.ALL-AL-99.A"}




* * *










